[官方原文在此](https://www.ccdcsm.com/documentation/4.0/zh/manual/installation/install/building_windows_agent_binaries)，我只是按阅读习惯重新写了一遍<br>

### 编译 OPENSSL<br>
以下步骤将帮助您从 MS Windows 10 (64位) 上的源代码编译 OpenSSL 。<br>
1. OpenSSL 的环境准备<br>
    C compiler (例如。 VS 2015),<br>
    [NASM](https://www.nasm.us/),<br>
    Perl (eg. [Strawberry Perl](http://strawberryperl.com/)),<br>
2. [获取OpenSSL](https://www.openssl.org/),这里使用的是 OpenSSL 1.1.1。<br>
    解压 OpenSSL 源代码包，例如，解压至 E:\openssl-1.1.1。<br>
    打开命令行窗口，例如，Visual C++ 2015 x64 Native Build Tools Command Prompt<br>
    转到 OpenSSL 源代码包的解压目录，例如：E:\openssl-1.1.1。<br>
    确保 NASM 已安装且配置好环境变量<br>
        e:\openssl-1.1.1> nasm --version<br>
            NASM version 2.13.01 compiled on May  1 2017<br>
3. 安装 OpenSSL，eg<br>
    E:\openssl-1.1.1> perl E:\openssl-1.1.1\Configure VC-WIN64A no-shared no-capieng no-srp no-gost no-dgram no-dtls1-method no-dtls1_2-method  --api=1.1.0 --prefix=D:\OpenSSL-Win64-111-static --openssldir=D:\OpenSSL-Win64-111-static<br>
        需要注意此选项 'no-shared'：如果使用 'no-shared' ，则 OpenSSL 静态库 libcrypto.lib 和 libssl.lib 将会'自给自足'，并且其生成的 CCDCSM 二进制文件将会包含 libcrypto.lib 和 libssl.lib，无需外部的 OpenSSL DLLs。其优点是：CCDCSM 二进制文件可以复制到其他没有 OpenSSL 库的 Windows 机器上。其缺点是：当发布新的 OpenSSL bugfix 时，CCDCSM agent 需要重新编译和重新安装。<br>
        如果不使用 'no-shared'，则静态库 libcrypto.lib 和 libssl.lib 将在启动时运行 OpenSSL。其优点是：当发布新的 OpenSSL bugfix 时，或许只需要升级 OpenSSL DLLs，而无需重新编译 CCDCSM agent。其缺点是：当将 CCDCSM agent 拷贝到其他机器上时，需要同时拷贝 OpenSSL DLLs。<br>
4. 编译 OpenSSL、运行测试并安装：<br>
    E:\openssl-1.1.1> nmake<br>
    E:\openssl-1.1.1> nmake test<br>
        ......<br>
        All tests successful.<br>
        Files=152, Tests=1152, 501 wallclock secs ( 0.67 usr +  0.61 sys =  1.28 CPU)<br>
        Result: PASS<br>
    E:\openssl-1.1.1> nmake install_sw<br>
        ps. install_sw 只安装软件组件（例如。库、头部文件，但没有文档）。如果想要全部组件，请使用 "nmake install"。<br>

### 编译 PCRE<br>
1. 从pcre.org下载 PCRE 库（CCDCSM 4.0 中是强制的库）。版本是[8.XX](https://ftp.pcre.org/pub/pcre/pcre-8.41.zip)；而不是pcre2 <br>
    将其解压至目录 E:\pcre-8.41<br>
    创建一个新的、空的构建目录，最好是在源目录的子目录下。例如：E:\pcre-8.41\build。<br>
2. 安装[CMake](https://cmake.org/files/v3.9/cmake-3.9.4-win64-x64.zip)，并配置环境变量<br>
    打开一个 Windows 命令行。例如 Visual C++ 2015 x64 Native Build Tools Command Prompt 和在该 shell 环境种运行 cmake-gui。不要尝试从 Windows 开始菜单去启动 Cmake，因为这可能会导致错误。<br>
    2.1 分别为源和源目录键入 E:\pcre-8.41 和 E:\pcre-8.41\build 。<br>
        点击 "Configure" 按钮。<br>
        当为此项目指定生成器时，选择 "NMake Makefiles"。<br>
    2.2 创建一个新的、空的安装目录。例如：D:\PCRE。<br>
        GUI将会列出几个配置选项。 确保选中以下选项：<br>
            PCRE_SUPPORT_UNICODE_PROPERTIES ON<br>
            PCRE_SUPPORT_UTF ON<br>
            CMAKE_INSTALL_PREFIX D:\PCRE<br>
            CMAKE_BUILD_TYPE Release<br>
        再次点击 "Configure" 。其相邻的 "Generate" 按钮应该被激活。<br>
        点击 "Generate"。<br>
        如果确实发生了错误。建议在尝试重新构建 CMake 过程之前删除 CMake 缓存。在 CMake GUI 中，可以通过选择 "File > Delete Cache" 来删除缓存。<br>
        其构建目录现在应该包含一个可用构建系统- Makefile。<br>
    2.3 打开 Windows 命令行。例如 Visual C++ 2015 x64 Native Build Tools Command Prompt ，并切换到上面提及的 Makefile 。<br>
        E:\pcre-8.41\build> nmake install<br>


### 编译 CCDCSM<br>
1. 在 `Linux` 机器上检查 git 的源代码：<br>
    git clone git@10.0.99.33:ccdcsm/ccdcsm.git<br>
    cd ccdcsm<br>
    ./bootstrap.sh<br>
    ./configure --enable-agent --enable-ipv6 --prefix=`pwd`<br>
    make dbschema<br>
    make dist<br>
2. 复制并解压文件到`windows`: ccdcsm-4.2.8.tar.gz<br>
3. 假设源文件位于 E:\ccdcsm-4.2.8。则打开 Windows 命令行，例如，Visual C++ 2015 x64 Native Build Tools Command Prompt ，并切换到 E:\ccdcsm-4.2.8\build\win32\project。<br>
4. 编译 ccdcsm_get、ccdcsm_sender 和 ccdcsm_agent。<br>
    4.1 不使用 TLS：<br>
        E:\ccdcsm-4.2.8\build\win32\project> nmake /K PCREINCDIR=D:\PCRE\include PCRELIBDIR=D:\PCRE\lib<br>
    4.2 使用 TLS：<br>
        E:\ccdcsm-4.2.8\build\win32\project> nmake /K -f Makefile_get TLS=openssl TLSINCDIR=D:\OpenSSL-Win64-111-static\include TLSLIBDIR=D:\OpenSSL-Win64-111-static\lib PCREINCDIR=D:\PCRE\include PCRELIBDIR=D:\PCRE\lib<br>
        E:\ccdcsm-4.2.8\build\win32\project> nmake /K -f Makefile_sender TLS=openssl TLSINCDIR="D:\OpenSSL-Win64-111-static\include TLSLIBDIR="D:\OpenSSL-Win64-111-static\lib" PCREINCDIR=D:\PCRE\include PCRELIBDIR=D:\PCRE\lib<br>
        E:\ccdcsm-4.2.8\build\win32\project> nmake /K -f Makefile_agent TLS=openssl TLSINCDIR=D:\OpenSSL-Win64-111-static\include TLSLIBDIR=D:\OpenSSL-Win64-111-static\lib PCREINCDIR=D:\PCRE\include PCRELIBDIR=D:\PCRE\lib<br>
    新的二进制文件位于 e:\ccdcsm-4.2.8\bin\win64 下。 由于 OpenSSL 是使用 'no-shared' 选项编译的，因此 CCDCSM 二进制文件自身包含 OpenSSL ，并且可以复制到其他没有 OpenSSL 的机器上。<br>