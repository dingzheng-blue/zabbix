1. 准备依赖包
    yum install rpm-build gcc gcc-c++ curl-devel libssh2-devel OpenIPMI-devel
2. 输入rpmbuild建立相关目录
    rpmbuild
3.  将源码包移动到SOURCES目录下
    mv ccdcsm-4.2.8.tar.gz /root/rpmbuild/SOURCES
4. 将spec文件移动到SPECS目录下
    mv zabbix-agent.spec /root/rpmbuild/SPECS
5. 执行命令进行rpm包构建
    rpmbuild -bb zabbix-agent.spec